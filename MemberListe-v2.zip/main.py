import discord
from discord.ext import commands, tasks
import json
import os
import asyncio

# Define the intents
intents = discord.Intents.default()
intents.members = True
intents.presences = True
intents.message_content = True

bot = commands.Bot(command_prefix='/', intents=intents)

# Define the role IDs
role_ids = [
    1261386804410585234,  # Oyabun
    1261386804410585233,  # Konsarutanto
    1261386804410585232,  # Kaikeishi
    1261386804381093954,  # Bijinesuman
    1261386804381093953,  # Taishi
    1261390745739198565,  # Kohosha
]

# Admin role IDs
admin_role_ids = [1261386804410585234, 1261386804410585233]

# Define the channel and message IDs
state_file = 'bot_state.json'
channel_id = None
message_id = None

lager_channel_id = None
lager_message_id = None
lager_items = {}

rate_limit_tasks = []

# Load state from a file
def load_state():
    global channel_id, message_id, lager_channel_id, lager_message_id, lager_items
    if os.path.exists(state_file):
        with open(state_file, 'r') as f:
            data = json.load(f)
            channel_id = data.get('channel_id')
            message_id = data.get('message_id')
            lager_channel_id = data.get('lager_channel_id')
            lager_message_id = data.get('lager_message_id')
            lager_items = data.get('lager_items', {})

# Save state to a file
def save_state():
    data = {
        'channel_id': channel_id,
        'message_id': message_id,
        'lager_channel_id': lager_channel_id,
        'lager_message_id': lager_message_id,
        'lager_items': lager_items
    }
    with open(state_file, 'w') as f:
        json.dump(data, f)

@bot.event
async def on_ready():
    print(f'{bot.user} has connected to Discord!')
    load_state()
    if channel_id and message_id:
        await update_member_list_on_ready()
    if lager_channel_id and lager_message_id:
        await update_lager_on_ready()

@bot.command(name='verifystart')
@commands.has_any_role(*admin_role_ids)
async def verifystart(ctx):
    global channel_id
    global message_id
    channel_id = ctx.channel.id
    embed = discord.Embed(title='Member Liste', description='', color=0xff0000)
    message = await ctx.send(embed=embed)
    message_id = message.id
    await update_member_list(ctx)
    save_state()
    await ctx.message.delete()

@verifystart.error
async def verifystart_error(ctx, error):
    if isinstance(error, commands.MissingAnyRole):
        msg = await ctx.send("Sie sind nicht befugt, diesen Befehl zu verwenden.")
        await ctx.message.delete()
        await msg.delete(delay=10)

@bot.event
async def on_member_update(before, after):
    if channel_id:
        await update_member_list(before)

async def update_member_list(ctx_or_before):
    global message_id
    members = {}
    for role_id in role_ids:
        role = ctx_or_before.guild.get_role(role_id)
        members[role.name] = [f'{member.mention}' for member in role.members]

    member_count = sum(len(role.members) for role_id in role_ids for role in ctx_or_before.guild.roles if role.id == role_id)

    table = f'**Member List ({member_count} members)**\n'
    for role_name, member_list in members.items():
        table += f'**{role_name}**\n'
        for member in member_list:
            table += f'- {member}\n'
        table += '\n'

    channel = bot.get_channel(channel_id)
    message = await channel.fetch_message(message_id)
    embed = discord.Embed(title='Member Liste', description=table, color=0xff0000)
    await message.edit(embed=embed)

async def update_member_list_on_ready():
    guild = bot.get_guild(bot.guilds[0].id)
    members = {}
    for role_id in role_ids:
        role = guild.get_role(role_id)
        members[role.name] = [f'{member.mention}' for member in role.members]

    member_count = sum(len(role.members) for role_id in role_ids for role in guild.roles if role.id == role_id)

    table = f'**Member List ({member_count} members)**\n'
    for role_name, member_list in members.items():
        table += f'**{role_name}**\n'
        for member in member_list:
            table += f'- {member}\n'
        table += '\n'

    channel = bot.get_channel(channel_id)
    message = await channel.fetch_message(message_id)
    embed = discord.Embed(title='Member Liste', description=table, color=0xff0000)
    await message.edit(embed=embed)

@bot.command(name='lagerstart')
@commands.has_any_role(*admin_role_ids)
async def lagerstart(ctx):
    global lager_channel_id
    global lager_message_id
    lager_channel_id = ctx.channel.id
    embed = discord.Embed(title='Lager', description='**Lagerbestand:**\n', color=0xff0000)
    message = await ctx.send(embed=embed)
    lager_message_id = message.id
    save_state()
    await ctx.message.delete()

@lagerstart.error
async def lagerstart_error(ctx, error):
    if isinstance(error, commands.MissingAnyRole):
        msg = await ctx.send("Sie sind nicht befugt, diesen Befehl zu verwenden.")
        await ctx.message.delete()
        await msg.delete(delay=10)

@bot.command(name='geben')
async def geben(ctx, item_name: str, quantity: int):
    global lager_items
    lager_items[item_name] = lager_items.get(item_name, 0) + quantity
    await update_lager(ctx)
    save_state()
    await ctx.message.delete()

@bot.command(name='nehmen')
async def nehmen(ctx, item_name: str, quantity: int):
    global lager_items
    if item_name in lager_items:
        lager_items[item_name] -= quantity
        if lager_items[item_name] <= 0:
            del lager_items[item_name]
    await update_lager(ctx)
    save_state()
    await ctx.message.delete()

@bot.command(name='remove')
@commands.has_any_role(*admin_role_ids)
async def remove(ctx, item_name: str, quantity: int):
    global lager_items
    if item_name in lager_items:
        lager_items[item_name] -= quantity
        if lager_items[item_name] <= 0:
            del lager_items[item_name]
    await update_lager(ctx)
    save_state()
    await ctx.message.delete()

@remove.error
async def remove_error(ctx, error):
    if isinstance(error, commands.MissingAnyRole):
        msg = await ctx.send("Sie sind nicht befugt, diesen Befehl zu verwenden.")
        await ctx.message.delete()
        await msg.delete(delay=10)

@bot.command(name='clear')
@commands.has_any_role(*admin_role_ids)
async def clear(ctx):
    global lager_items
    lager_items = {}
    await update_lager(ctx)
    save_state()
    await ctx.message.delete()

@clear.error
async def clear_error(ctx, error):
    if isinstance(error, commands.MissingAnyRole):
        msg = await ctx.send("Sie sind nicht befugt, diesen Befehl zu verwenden.")
        await ctx.message.delete()
        await msg.delete(delay=10)

async def update_lager(ctx):
    global lager_message_id
    table = '**Lagerbestand:**\n'
    for item_name, quantity in lager_items.items():
        table += f'- {item_name} ({quantity})\n'
    channel = bot.get_channel(lager_channel_id)
    message = await channel.fetch_message(lager_message_id)
    embed = discord.Embed(title='Lager', description=table, color=0xff0000)
    await message.edit(embed=embed)

async def update_lager_on_ready():
    table = '**Lagerbestand:**\n'
    for item_name, quantity in lager_items.items():
        table += f'- {item_name} ({quantity})\n'
    channel = bot.get_channel(lager_channel_id)
    message = await channel.fetch_message(lager_message_id)
    embed = discord.Embed(title='Lager', description=table, color=0xff0000)
    await message.edit(embed=embed)

@bot.event
async def on_message(message):
    if message.author == bot.user:
        return

    # Check if the message is in the active verification or lager channel
    if (message.channel.id == channel_id) or (message.channel.id == lager_channel_id):
        if not message.content.startswith('/'):
            await asyncio.sleep(3)  # Delay of 3 seconds
            try:
                await message.delete()
            except discord.HTTPException as e:
                print(f"Error deleting message: {e}")
            return

        ctx = await bot.get_context(message)
        if not ctx.valid:
            await asyncio.sleep(3)  # Delay of 3 seconds
            try:
                await message.delete()
            except discord.HTTPException as e:
                print(f"Error deleting message: {e}")
            return

    await bot.process_commands(message)

bot.run('MTI2OTg1ODQ0OTM2MjEyNDg2Mw.GiQHk7.51FGrzgylz0OJ6MEOh3MYMQv7ddB4sgGoPAXn8')
